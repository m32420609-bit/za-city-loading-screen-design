import { useEffect, useRef, useState } from "react";

export type LoadPhase = "boot" | "connect" | "files" | "finishing" | "done";

export interface GmodState {
  serverName: string;
  mapName: string;
  gameMode: string;
  maxPlayers: number;
  steamId: string;
  phase: LoadPhase;
  status: string;
  filesTotal: number;
  filesNeeded: number;
  currentFile: string;
  log: string[];
  isLive: boolean;
}

declare global {
  interface Window {
    GameDetails?: (
      serverName: string,
      serverUrl: string,
      mapName: string,
      maxPlayers: number,
      steamId: string,
      gameMode: string
    ) => void;
    SetStatusChanged?: (status: string) => void;
    SetFilesTotal?: (total: number) => void;
    SetFilesNeeded?: (needed: number) => void;
    DownloadingFile?: (fileName: string) => void;
    __ZA_LIVE__?: boolean;
  }
}

const DEMO_FILES = [
  "materials/zacity/hud/hud_main.vmt",
  "materials/zacity/hud/hud_main.vtf",
  "resource/fonts/zacity_display.ttf",
  "sound/zacity/ambience/night_city.wav",
  "models/zacity/cars/nissan_gtr35.mdl",
  "models/zacity/cars/nissan_gtr35.phy",
  "materials/models/zacity/gtr35/body.vmt",
  "materials/models/zacity/gtr35/body.vtf",
  "models/zacity/props/shop_kiosk.mdl",
  "materials/zacity/neon/sign_neon_01.vmt",
  "materials/zacity/neon/sign_neon_02.vmt",
  "lua/zacity/client/cl_hud.lua",
  "lua/zacity/client/cl_cars.lua",
  "sound/zacity/music/loading_theme.mp3",
  "models/zacity/police/lada_vesta.mdl",
  "materials/models/zacity/vesta/paint_blue.vmt",
  "models/zacity/jobs/taxi_volga.mdl",
  "sound/zacity/ui/notify.wav",
  "materials/zacity/map/minimap_overlay.vmt",
  "models/zacity/props/atm_terminal.mdl",
  "materials/zacity/props/atm_screen.vmt",
  "lua/zacity/shared/sh_config.lua",
  "sound/zacity/cars/engine_v8.wav",
  "materials/zacity/decals/graffiti_04.vmt",
  "models/zacity/citizens/citizen_female_02.mdl",
  "materials/zacity/citizens/skin_04.vmt",
  "sound/zacity/siren/police_loop.wav",
  "models/zacity/props/street_light.mdl",
  "materials/zacity/neon/casino_sign.vmt",
  "lua/zacity/server/sv_economy.lua",
  "sound/zacity/phone/sms.wav",
  "materials/zacity/phone/os_icons.vtf",
];

const DEMO_STATUS = [
  "Подключение к серверу...",
  "Синхронизация контента...",
  "Загрузка ресурсов сервера...",
  "Проверка файлов...",
];

function nowStamp() {
  const t = performance.now() / 1000;
  return `T+${t.toFixed(2).padStart(7, "0")}s`;
}

export function useGmodLoader() {
  const [state, setState] = useState<GmodState>(() => {
    const q = new URLSearchParams(window.location.search);
    return {
      serverName: "ZA-CITY | ОТКРЫТЫЙ БЕТА-ТЕСТ",
      mapName: q.get("mapname") ?? q.get("map") ?? "rp_zacity_v2",
      gameMode: q.get("gamemode") ?? "darkrp",
      maxPlayers: Number(q.get("maxplayers") ?? 66),
      steamId: q.get("steamid") ?? "STEAM_0:1:00000000",
      phase: "boot",
      status: "Инициализация клиента...",
      filesTotal: 0,
      filesNeeded: 0,
      currentFile: "",
      log: [],
      isLive: false,
    };
  });

  const liveRef = useRef(false);
  const fileCounter = useRef(0);

  useEffect(() => {
    const pushLog = (line: string) =>
      setState((s) => ({ ...s, log: [...s.log.slice(-4), `[${nowStamp()}] ${line}`] }));

    /* ---------- REAL GARRY'S MOD BINDINGS ---------- */

    window.GameDetails = (serverName, _serverUrl, mapName, maxPlayers, steamId, gameMode) => {
      liveRef.current = true;
      window.__ZA_LIVE__ = true;
      setState((s) => ({
        ...s,
        isLive: true,
        serverName: serverName || s.serverName,
        mapName: mapName || s.mapName,
        gameMode: gameMode || s.gameMode,
        maxPlayers: maxPlayers || s.maxPlayers,
        steamId: steamId || s.steamId,
        phase: "connect",
        status: "Подключение к серверу...",
      }));
      pushLog("Соединение установлено");
    };

    window.SetStatusChanged = (status) => {
      setState((s) => ({ ...s, status }));
      pushLog(status);
    };

    window.SetFilesTotal = (total) => {
      setState((s) => ({ ...s, filesTotal: total, filesNeeded: total, phase: total > 0 ? "files" : s.phase }));
    };

    window.SetFilesNeeded = (needed) => {
      setState((s) => ({ ...s, filesNeeded: needed }));
      if (needed === 0) pushLog("Все файлы получены");
    };

    window.DownloadingFile = (fileName) => {
      fileCounter.current += 1;
      setState((s) => ({ ...s, currentFile: fileName, phase: "files" }));
      if (fileCounter.current % 6 === 0) pushLog(`Скачано файлов: ${fileCounter.current}`);
    };

    /* ---------- DEMO MODE (browser preview) ---------- */

    if (!window.__ZA_LIVE__) {
      let cancelled = false;
      const timers: number[] = [];
      const run = (fn: () => void, delay: number) => {
        const id = window.setTimeout(() => !cancelled && fn(), delay);
        timers.push(id);
      };

      run(() => {
        if (liveRef.current) return;
        pushLog(DEMO_STATUS[0]);
        setState((s) => ({ ...s, phase: "connect", status: DEMO_STATUS[0] }));
      }, 500);

      run(() => {
        if (liveRef.current) return;
        pushLog("Соединение установлено");
        pushLog(DEMO_STATUS[1]);
        setState((s) => ({ ...s, status: DEMO_STATUS[1] }));
      }, 1900);

      run(() => {
        if (liveRef.current) return;
        const total = DEMO_FILES.length + 41;
        setState((s) => ({
          ...s,
          phase: "files",
          status: DEMO_STATUS[2],
          filesTotal: total,
          filesNeeded: total,
        }));
        pushLog(`Найдено файлов для загрузки: ${total}`);

        let i = 0;
        const interval = window.setInterval(() => {
          if (cancelled || liveRef.current) {
            window.clearInterval(interval);
            return;
          }
          i += 1;
          const file =
            DEMO_FILES[Math.floor(Math.random() * DEMO_FILES.length)] + (i > 18 ? ` (${i})` : "");
          setState((s) => {
            const needed = Math.max(0, s.filesTotal - (1 + Math.floor(Math.random() * 3)));
            return { ...s, currentFile: file, filesNeeded: needed, status: DEMO_STATUS[2] };
          });
          if (i % 9 === 0) pushLog(`Загружено пакетов: ${Math.floor(i * 1.8)}`);

          if (i >= 26) {
            window.clearInterval(interval);
            setState((s) => ({
              ...s,
              filesNeeded: 0,
              phase: "finishing",
              status: "Финальная синхронизация...",
              currentFile: "spawn/zacity_precache.lua",
            }));
            pushLog("Все файлы получены");
            run(() => {
              pushLog("Спавн игрока...");
              setState((s) => ({ ...s, status: "Подготовка мира ZA-CITY..." }));
            }, 1200);
            run(() => {
              setState((s) => ({ ...s, phase: "done", status: "Добро пожаловать в ZA-CITY" }));
              pushLog("Добро пожаловать в ZA-CITY!");
            }, 2600);
          }
        }, 420);
        timers.push(interval);
      }, 3400);

      return () => {
        cancelled = true;
        timers.forEach((t) => {
          window.clearTimeout(t);
          window.clearInterval(t);
        });
      };
    }
  }, []);

  return state;
}
