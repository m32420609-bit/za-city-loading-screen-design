import { Volume2, VolumeX } from "lucide-react";
import { useEffect, useRef, useState } from "react";

/* Generative synthwave ambience: pads + arps + rain hiss (WebAudio, no assets) */

const CHORDS: number[][] = [
  [110.0, 130.81, 164.81, 196.0], // Am7-ish
  [87.31, 110.0, 130.81, 164.81], // Fmaj-ish
  [98.0, 123.47, 146.83, 196.0], // G
  [103.83, 130.81, 155.56, 196.0], // Ab maj color
];

const ARP_NOTES = [220.0, 261.63, 293.66, 329.63, 392.0, 440.0, 523.25];

class AmbientEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private chordTimer = 0;
  private arpTimer = 0;
  private chordIdx = 0;
  private running = false;

  start() {
    if (this.running) {
      void this.ctx?.resume();
      return;
    }
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    this.ctx = ctx;
    this.running = true;

    const master = ctx.createGain();
    master.gain.value = 0;
    master.gain.linearRampToValueAtTime(0.16, ctx.currentTime + 2.5);
    master.connect(ctx.destination);
    this.master = master;

    // delay for arps
    const delay = ctx.createDelay(1);
    delay.delayTime.value = 0.38;
    const feedback = ctx.createGain();
    feedback.gain.value = 0.36;
    const wet = ctx.createGain();
    wet.gain.value = 0.33;
    delay.connect(feedback);
    feedback.connect(delay);
    delay.connect(wet);
    wet.connect(master);

    // rain hiss
    const noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const data = noiseBuf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < data.length; i++) {
      const white = Math.random() * 2 - 1;
      last = (last + 0.02 * white) / 1.02;
      data[i] = last * 3.5 + white * 0.12;
    }
    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuf;
    noise.loop = true;
    const hissFilter = ctx.createBiquadFilter();
    hissFilter.type = "bandpass";
    hissFilter.frequency.value = 4200;
    hissFilter.Q.value = 0.5;
    const hissGain = ctx.createGain();
    hissGain.gain.value = 0.05;
    noise.connect(hissFilter);
    hissFilter.connect(hissGain);
    hissGain.connect(master);
    noise.start();

    const rumble = ctx.createBufferSource();
    rumble.buffer = noiseBuf;
    rumble.loop = true;
    const rumbleFilter = ctx.createBiquadFilter();
    rumbleFilter.type = "lowpass";
    rumbleFilter.frequency.value = 130;
    const rumbleGain = ctx.createGain();
    rumbleGain.gain.value = 0.16;
    rumble.connect(rumbleFilter);
    rumbleFilter.connect(rumbleGain);
    rumbleGain.connect(master);
    rumble.start();

    const playChord = () => {
      if (!this.ctx || !this.master) return;
      const now = this.ctx.currentTime;
      const chord = CHORDS[this.chordIdx % CHORDS.length];
      this.chordIdx += 1;
      for (const freq of chord) {
        for (const detune of [-5, 5]) {
          const osc = this.ctx.createOscillator();
          osc.type = "sawtooth";
          osc.frequency.value = freq;
          osc.detune.value = detune;
          const filter = this.ctx.createBiquadFilter();
          filter.type = "lowpass";
          filter.frequency.setValueAtTime(320, now);
          filter.frequency.linearRampToValueAtTime(900, now + 2.2);
          filter.frequency.linearRampToValueAtTime(300, now + 5.4);
          const g = this.ctx.createGain();
          g.gain.setValueAtTime(0, now);
          g.gain.linearRampToValueAtTime(0.045, now + 1.6);
          g.gain.setValueAtTime(0.045, now + 3.6);
          g.gain.linearRampToValueAtTime(0, now + 5.6);
          osc.connect(filter);
          filter.connect(g);
          g.connect(this.master);
          osc.start(now);
          osc.stop(now + 5.8);
        }
      }
      this.chordTimer = window.setTimeout(playChord, 5200);
    };

    const playArp = () => {
      if (!this.ctx || !this.master) return;
      const now = this.ctx.currentTime;
      if (Math.random() < 0.8) {
        const freq = ARP_NOTES[Math.floor(Math.random() * ARP_NOTES.length)] * (Math.random() < 0.3 ? 2 : 1);
        const osc = this.ctx.createOscillator();
        osc.type = "triangle";
        osc.frequency.value = freq;
        const g = this.ctx.createGain();
        g.gain.setValueAtTime(0.09, now);
        g.gain.exponentialRampToValueAtTime(0.0001, now + 0.9);
        osc.connect(g);
        g.connect(this.master);
        g.connect(delay);
        osc.start(now);
        osc.stop(now + 1);
      }
      this.arpTimer = window.setTimeout(playArp, 300 + Math.random() * 900);
    };

    playChord();
    playArp();
  }

  stop() {
    if (!this.ctx) return;
    void this.ctx.suspend();
    window.clearTimeout(this.chordTimer);
    window.clearTimeout(this.arpTimer);
  }
}

export default function AudioToggle() {
  const engineRef = useRef<AmbientEngine | null>(null);
  const [enabled, setEnabled] = useState(false);

  useEffect(() => {
    engineRef.current = new AmbientEngine();
  }, []);

  const toggle = () => {
    const engine = engineRef.current;
    if (!engine) return;
    if (enabled) {
      engine.stop();
      setEnabled(false);
    } else {
      engine.start();
      setEnabled(true);
    }
  };

  return (
    <button
      onClick={toggle}
      className="group flex items-center gap-2.5 border border-white/10 bg-black/40 px-3.5 py-2 backdrop-blur-sm transition-colors duration-300 hover:border-neon/60"
      aria-label="Переключить звук"
    >
      {enabled ? (
        <div className="flex h-3.5 items-end gap-[2.5px]">
          {[0.9, 0.5, 0.7, 0.3].map((d, i) => (
            <span
              key={i}
              className="w-[2.5px] origin-bottom animate-[breathe_0.8s_ease-in-out_infinite] bg-neon"
              style={{ height: "100%", animationDelay: `${d}s`, transformOrigin: "bottom" }}
            />
          ))}
        </div>
      ) : (
        <VolumeX className="h-3.5 w-3.5 text-white/50 transition-colors group-hover:text-neon" />
      )}
      {enabled && <Volume2 className="hidden" />}
      <span className="font-mono text-[0.62rem] font-bold uppercase tracking-[0.28em] text-white/60 transition-colors group-hover:text-white">
        {enabled ? "Звук вкл" : "Звук"}
      </span>
    </button>
  );
}
