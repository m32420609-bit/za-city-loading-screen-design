export default function Logo() {
  const title = "ZA-CITY";
  return (
    <div className="select-none">
      <h1
        className="glitch-wrap font-display text-[clamp(1.9rem,4vw,3.4rem)] font-black leading-none tracking-tight"
        data-text={title}
      >
        <span className="bg-gradient-to-r from-neon via-white to-magenta bg-clip-text text-transparent italic">
          {title}
        </span>
      </h1>
      <div className="mt-2.5 flex items-center gap-3">
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-limey opacity-70" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-limey" />
        </span>
        <span className="font-mono text-[0.62rem] font-extrabold uppercase tracking-[0.42em] text-limey sm:text-[0.7rem]">
          Open Beta Test
        </span>
        <span className="hidden font-mono text-[0.6rem] uppercase tracking-[0.2em] text-white/35 sm:block">
          v0.9.7-public
        </span>
      </div>
    </div>
  );
}
