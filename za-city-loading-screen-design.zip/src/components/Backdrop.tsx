import { useEffect, useRef } from "react";

/* ---------- seeded rng ---------- */
function mulberry32(seed: number) {
  return () => {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface WindowDot {
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  phase: number;
  speed: number;
}

interface Building {
  x: number;
  w: number;
  h: number;
  antenna: boolean;
  neon: string | null;
  windows: WindowDot[];
}

interface LayerSpec {
  seed: number;
  color: string;
  hMin: number;
  hMax: number;
  speed: number;
  windowAlpha: number;
}

const LAYERS: LayerSpec[] = [
  { seed: 11, color: "#131a33", hMin: 0.1, hMax: 0.26, speed: 6, windowAlpha: 0.5 },
  { seed: 42, color: "#0d1226", hMin: 0.14, hMax: 0.34, speed: 12, windowAlpha: 0.75 },
  { seed: 77, color: "#070b19", hMin: 0.18, hMax: 0.44, speed: 20, windowAlpha: 1 },
];

const WINDOW_COLORS = ["#4de3ff", "#f27bf0", "#ffd166", "#c8f75e", "#8aa7ff"];

function buildLayer(spec: LayerSpec, width: number, height: number, horizon: number): Building[] {
  const rnd = mulberry32(spec.seed * 1000 + Math.floor(height));
  const buildings: Building[] = [];
  let x = -40;
  while (x < width + 80) {
    const w = 26 + rnd() * 84;
    const h = height * (spec.hMin + rnd() * (spec.hMax - spec.hMin));
    const windows: WindowDot[] = [];
    const cols = Math.floor(w / 14);
    const rows = Math.floor(h / 22);
    for (let c = 0; c < cols; c++) {
      for (let r = 0; r < rows; r++) {
        if (rnd() < 0.42) {
          windows.push({
            x: 6 + c * 14,
            y: 8 + r * 22,
            w: 5 + rnd() * 2,
            h: 8 + rnd() * 3,
            color: WINDOW_COLORS[Math.floor(rnd() * WINDOW_COLORS.length)],
            phase: rnd() * Math.PI * 2,
            speed: 0.15 + rnd() * 0.5,
          });
        }
      }
    }
    buildings.push({
      x,
      w,
      h,
      antenna: rnd() < 0.3,
      neon: rnd() < 0.22 ? WINDOW_COLORS[Math.floor(rnd() * WINDOW_COLORS.length)] : null,
      windows,
    });
    x += w + 6 + rnd() * 34;
  }
  void horizon;
  return buildings;
}

interface Drop {
  x: number;
  y: number;
  len: number;
  speed: number;
  alpha: number;
}

export default function Backdrop() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = 0;
    let h = 0;
    let horizon = 0;
    let raf = 0;
    let layers: Building[][] = [];
    let drops: Drop[] = [];

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.6);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      horizon = h * 0.66;
      layers = LAYERS.map((spec) => buildLayer(spec, w, h, horizon));
      const rnd = mulberry32(999);
      drops = Array.from({ length: Math.min(170, Math.floor(w / 9)) }, () => ({
        x: rnd() * w,
        y: rnd() * h,
        len: 10 + rnd() * 22,
        speed: 380 + rnd() * 420,
        alpha: 0.05 + rnd() * 0.16,
      }));
    };

    const drawSun = (t: number) => {
      const cx = w * 0.5;
      const cy = horizon - h * 0.01;
      const r = Math.min(w, h) * 0.24;

      const g = ctx.createLinearGradient(0, cy - r, 0, cy + r);
      g.addColorStop(0, "#ffd166");
      g.addColorStop(0.45, "#ff7ab8");
      g.addColorStop(1, "#a04df0");
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.clip();
      ctx.fillStyle = g;
      ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
      // horizontal cut stripes, widening downward
      let y = cy - r * 0.05;
      let gap = 3;
      const step = r * 0.11;
      while (y < cy + r) {
        ctx.fillStyle = "#05070f";
        ctx.fillRect(cx - r - 2, y, r * 2 + 4, gap);
        y += step;
        gap += 1.6;
      }
      ctx.restore();

      // glow
      const glow = ctx.createRadialGradient(cx, cy, r * 0.2, cx, cy, r * 2.4);
      glow.addColorStop(0, `rgba(255, 122, 184, ${0.14 + Math.sin(t * 0.8) * 0.03})`);
      glow.addColorStop(1, "rgba(255, 122, 184, 0)");
      ctx.fillStyle = glow;
      ctx.fillRect(cx - r * 2.4, cy - r * 2.4, r * 4.8, r * 4.8);
    };

    const drawLayer = (spec: LayerSpec, buildings: Building[], t: number) => {
      const offset = (t * spec.speed) % (w + 120);
      ctx.save();
      ctx.translate(-offset, 0);
      for (let pass = 0; pass < 2; pass++) {
        ctx.translate(pass * (w + 120), 0);
        ctx.fillStyle = spec.color;
        for (const b of buildings) {
          ctx.fillRect(b.x, horizon - b.h, b.w, b.h + 2);
          if (b.antenna) {
            ctx.fillRect(b.x + b.w / 2 - 1, horizon - b.h - 26, 2, 26);
            ctx.fillStyle = t % 1.4 < 0.7 ? "#ff4d6d" : "rgba(255,77,109,0.25)";
            ctx.fillRect(b.x + b.w / 2 - 2, horizon - b.h - 30, 4, 4);
            ctx.fillStyle = spec.color;
          }
          if (b.neon) {
            ctx.save();
            ctx.shadowColor = b.neon;
            ctx.shadowBlur = 14;
            ctx.fillStyle = b.neon;
            ctx.globalAlpha = 0.5 + Math.sin(t * 2 + b.x) * 0.2;
            ctx.fillRect(b.x + 3, horizon - b.h + 10, 3, Math.max(14, b.h * 0.5));
            ctx.restore();
          }
          // windows
          for (const win of b.windows) {
            const flicker = Math.sin(t * win.speed + win.phase);
            if (flicker < -0.82) continue;
            ctx.globalAlpha = spec.windowAlpha * (0.35 + 0.65 * Math.abs(flicker));
            ctx.fillStyle = win.color;
            ctx.fillRect(b.x + win.x, horizon - b.h + win.y, win.w, win.h);
            ctx.globalAlpha = 1;
            ctx.fillStyle = spec.color;
          }
        }
      }
      ctx.restore();
    };

    const drawGrid = (t: number) => {
      const vpx = w * 0.5;
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, horizon, w, h - horizon);
      ctx.clip();

      // floor base
      const fg = ctx.createLinearGradient(0, horizon, 0, h);
      fg.addColorStop(0, "rgba(11, 8, 30, 0.9)");
      fg.addColorStop(1, "#040609");
      ctx.fillStyle = fg;
      ctx.fillRect(0, horizon, w, h - horizon);

      // vertical converging lines
      for (let i = -18; i <= 18; i++) {
        const x2 = vpx + i * (w / 14);
        const grad = ctx.createLinearGradient(vpx, horizon, x2, h);
        grad.addColorStop(0, "rgba(77, 227, 255, 0)");
        grad.addColorStop(1, "rgba(77, 227, 255, 0.5)");
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(vpx, horizon);
        ctx.lineTo(x2, h);
        ctx.stroke();
      }

      // moving horizontal lines
      const rows = 14;
      const speed = 0.55;
      for (let i = 0; i < rows; i++) {
        const p = ((i + (t * speed) % 1) % rows) / rows;
        const y = horizon + Math.pow(p, 2.6) * (h - horizon);
        const alpha = Math.min(0.55, p * 0.9);
        ctx.strokeStyle = `rgba(242, 123, 240, ${alpha})`;
        ctx.lineWidth = p > 0.85 ? 1.6 : 1;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // horizon glow line
      const hg = ctx.createLinearGradient(0, 0, w, 0);
      hg.addColorStop(0, "rgba(77,227,255,0)");
      hg.addColorStop(0.5, "rgba(255,122,184,0.9)");
      hg.addColorStop(1, "rgba(77,227,255,0)");
      ctx.strokeStyle = hg;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, horizon);
      ctx.lineTo(w, horizon);
      ctx.stroke();
      ctx.restore();
    };

    const drawRain = (dt: number) => {
      ctx.save();
      ctx.lineWidth = 1;
      ctx.strokeStyle = "#9fd8ff";
      ctx.beginPath();
      for (const d of drops) {
        d.y += d.speed * dt;
        d.x -= d.speed * dt * 0.18;
        if (d.y > h) {
          d.y = -30;
          d.x = Math.random() * (w + 200);
        }
        ctx.globalAlpha = d.alpha;
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x - d.len * 0.18, d.y + d.len);
      }
      ctx.stroke();
      ctx.restore();
    };

    let last = performance.now();
    const start = last;

    const frame = (nowMs: number) => {
      raf = requestAnimationFrame(frame);
      const t = (nowMs - start) / 1000;
      const dt = Math.min(0.05, (nowMs - last) / 1000);
      last = nowMs;

      ctx.clearRect(0, 0, w, h);

      // sky
      const sky = ctx.createLinearGradient(0, 0, 0, horizon);
      sky.addColorStop(0, "#04060d");
      sky.addColorStop(0.55, "#0a0a24");
      sky.addColorStop(1, "#1d0b38");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, w, horizon + 1);

      // stars
      ctx.save();
      for (let i = 0; i < 70; i++) {
        const sx = ((i * 733) % w) + 3;
        const sy = ((i * 271) % Math.max(1, horizon * 0.72)) + 6;
        const tw = 0.25 + 0.75 * Math.abs(Math.sin(t * (0.4 + (i % 5) * 0.13) + i));
        ctx.globalAlpha = tw * 0.7;
        ctx.fillStyle = i % 7 === 0 ? "#f27bf0" : "#bfe9ff";
        ctx.fillRect(sx, sy, i % 9 === 0 ? 2 : 1.2, i % 9 === 0 ? 2 : 1.2);
      }
      ctx.restore();

      drawSun(t);
      drawLayer(LAYERS[0], layers[0], t);
      drawLayer(LAYERS[1], layers[1], t);

      drawGrid(t);

      drawLayer(LAYERS[2], layers[2], t);

      // haze above floor
      const haze = ctx.createLinearGradient(0, horizon - 60, 0, horizon + 100);
      haze.addColorStop(0, "rgba(29, 11, 56, 0)");
      haze.addColorStop(0.5, "rgba(242, 123, 240, 0.1)");
      haze.addColorStop(1, "rgba(4, 6, 9, 0)");
      ctx.fillStyle = haze;
      ctx.fillRect(0, horizon - 60, w, 160);

      drawRain(dt);
    };

    resize();
    window.addEventListener("resize", resize);
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="fixed inset-0 -z-10" aria-hidden />;
}
